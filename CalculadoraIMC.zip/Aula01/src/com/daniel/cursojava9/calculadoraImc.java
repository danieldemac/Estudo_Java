package com.daniel.cursojava9;

import java.text.DecimalFormat;
import java.util.Scanner;

public class calculadoraImc {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		DecimalFormat format = new DecimalFormat("###,###.##");
		
		System.out.println("Calculadora IMC");
		System.out.println("-|--|--|--|--|--|--|--|--|-");
		System.out.println("Digite seu nome: ");
		String nome = scan.nextLine();
		
		System.out.println("Digite sua altura em metros: ");
		double altura = scan.nextDouble();
		
		System.out.println("Digite seu peso em Kg: ");
		double peso = scan.nextDouble();
		
		double imc = peso / (altura * altura);
		
		
		System.out.print(nome+", o seu IMC � de: "+format.format(imc)+" ----> ");
		
		if(imc < 16) {
			System.out.print("Magreza grave");
			System.out.println();
			System.out.println("RECOMENDA��O DE NUTRICIONISTA");
		}else if(imc >= 16 && imc < 17) {
			System.out.print("Magreza moderada");
			System.out.println();
			System.out.println("RECOMENDA��O DE NUTRICIONISTA");
		}else if(imc >= 17 && imc < 18.5) {
			System.out.print("Magreza leve");
		}else if(imc >= 18.5 && imc <24.9){
			System.out.print("Normal");
		}else if(imc >= 24.9 && imc < 30){
			System.out.print("Sobrepeso");
			System.out.println();
			System.out.println("RECOMENDA��O DE NUTRICIONISTA");
		}else if(imc >= 30 && imc < 35){
		System.out.print("Obesidade GRAU I");
		System.out.println();
		System.out.println("RECOMENDA��O DE NUTRICIONISTA");
		}else if(imc >= 35 && imc < 40) {
		System.out.print("Obesidade GRAU II");
		System.out.println();
		System.out.println("RECOMENDA��O DE NUTRICIONISTA");
		}else if(imc >= 40) {
		System.out.print("Obesidade GRAU III");
		System.out.println();
		System.out.println("RECOMENDA��O DE NUTRICIONISTA");
		}
	
	
	
	
	
	
	
	
	
	
	}
}
